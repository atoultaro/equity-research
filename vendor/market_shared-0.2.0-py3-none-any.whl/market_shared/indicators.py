"""Finite-input EMA and simple ATR primitives; standard library only.

Inputs are ordered ``collections.abc.Sequence`` objects of real numbers (no
booleans, strings, NaN or infinity). Periods are positive integral values, excluding
bool. Bad types raise TypeError; invalid values raise ValueError, even for empty
inputs. Callers own time ordering, completed-bar availability and series identity.
No function sorts, groups, fills missing data or reads future observations.
"""

from collections.abc import Sequence
from math import isfinite
from numbers import Integral, Real
from statistics import mean
from typing import Literal


def _period(period: int) -> None:
    if isinstance(period, bool) or not isinstance(period, Integral):
        raise TypeError("period must be an integer")
    if period < 1:
        raise ValueError("period must be positive")


def _number(value: float) -> None:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError("values must be real numbers, excluding bool")
    if not isfinite(value):
        raise ValueError("values must be finite")


def _values(values: Sequence[float], *, nonnegative: bool = False) -> None:
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise TypeError("values must be a sequence of real numbers")
    for value in values:
        _number(value)
        if nonnegative and value < 0:
            raise ValueError("true ranges must be nonnegative")


def ema_last(values: Sequence[float], period: int) -> float:
    """Last EMA, seeded with the first value, alpha=2/(period+1); empty -> 0.

    No full-period warmup. Uses the legacy scalar operation order without rounding.
    """
    _period(period)
    _values(values)
    if not values:
        return 0.0
    alpha = 2.0 / (period + 1)
    result = values[0]
    for value in values[1:]:
        result = alpha * value + (1 - alpha) * result
    return result


def ema_series(values: Sequence[float], period: int) -> list[float]:
    """EMA at each input, same seed/alpha as ema_last; empty -> fresh empty list."""
    _period(period)
    _values(values)
    if not values:
        return []
    alpha = 2.0 / (period + 1)
    result = [values[0]]
    for value in values[1:]:
        result.append(alpha * value + (1 - alpha) * result[-1])
    return result


def true_range(high: float, low: float, previous_close: float | None = None) -> float:
    """max(high-low, abs(high-prev), abs(low-prev)); no prev -> high-low.

    All supplied numbers must be finite and high >= low. Negative price levels
    are permitted; positivity is a consumer-side instrument/data constraint.
    """
    _number(high)
    _number(low)
    if high < low:
        raise ValueError("high must be >= low")
    if previous_close is None:
        return high - low
    _number(previous_close)
    return max(high - low, abs(high - previous_close), abs(low - previous_close))


def atr_simple_last(true_ranges: Sequence[float], period: int) -> float:
    """Mean of last min(period, count) ranges via statistics.mean; empty -> 0.

    Partial history is averaged immediately. Ranges must be finite/nonnegative.
    This is a simple mean, not Wilder smoothing.
    """
    _period(period)
    _values(true_ranges, nonnegative=True)
    return mean(true_ranges[-period:]) if true_ranges else 0.0


def atr_simple_series(
    true_ranges: Sequence[float], period: int, *, warmup: Literal["missing", "partial"] = "missing",
) -> list[float | None]:
    """Rolling simple ATR, one output per range; empty -> fresh empty list.

    ``missing`` emits None until period ranges exist; ``partial`` averages the
    available prefix immediately. Uses the legacy ATR-tail add/subtract accumulator
    order, which can differ in last-bit rounding from statistics.mean or pandas.
    """
    _period(period)
    _values(true_ranges, nonnegative=True)
    if warmup not in {"missing", "partial"}:
        raise ValueError("warmup must be 'missing' or 'partial'")
    result: list[float | None] = []
    rolling_sum = 0.0
    for index, value in enumerate(true_ranges):
        rolling_sum += value
        if index >= period:
            rolling_sum -= true_ranges[index - period]
        if warmup == "missing" and index + 1 < period:
            result.append(None)
        else:
            result.append(rolling_sum / min(index + 1, period))
    return result
