from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Mapping


@dataclass(frozen=True)
class OhlcvBar:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    session: str | None = None
    vwap: float | None = None

    def __post_init__(self) -> None:
        if self.timestamp.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware")
        if self.high < self.low:
            raise ValueError("high must be >= low")
        if self.open <= 0 or self.high <= 0 or self.low <= 0 or self.close <= 0:
            raise ValueError("OHLC values must be positive")
        if self.volume < 0:
            raise ValueError("volume must be >= 0")


def _parse_timestamp(raw: object) -> datetime:
    if isinstance(raw, datetime):
        if raw.tzinfo is None:
            return raw.replace(tzinfo=timezone.utc)
        return raw
    text = str(raw).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    value = datetime.fromisoformat(text)
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def bar_from_mapping(
    row: Mapping[str, object],
    *,
    timestamp_key: str = "timestamp",
    vwap_key: str = "vwap",
) -> OhlcvBar:
    return OhlcvBar(
        timestamp=_parse_timestamp(row[timestamp_key]),
        open=float(row["open"]),
        high=float(row["high"]),
        low=float(row["low"]),
        close=float(row["close"]),
        volume=float(row.get("volume", 0.0)),
        session=str(row["session"]) if row.get("session") is not None else None,
        vwap=float(row[vwap_key]) if row.get(vwap_key) is not None else None,
    )


def bar_to_mapping(bar: OhlcvBar, *, vwap_key: str = "vwap") -> dict[str, object]:
    out: dict[str, object] = {
        "timestamp": bar.timestamp.isoformat(),
        "open": bar.open,
        "high": bar.high,
        "low": bar.low,
        "close": bar.close,
        "volume": bar.volume,
        "session": bar.session,
    }
    out[vwap_key] = bar.vwap
    return out


def _bucket_start(ts: datetime, interval_minutes: int) -> datetime:
    minute = (ts.minute // interval_minutes) * interval_minutes
    return ts.replace(minute=minute, second=0, microsecond=0)


def _aggregate_chunk(chunk: list[OhlcvBar], bucket_ts: datetime) -> OhlcvBar:
    total_volume = sum(bar.volume for bar in chunk)
    if total_volume > 0:
        weighted_pv = 0.0
        for bar in chunk:
            reference = bar.vwap if bar.vwap is not None else bar.close
            weighted_pv += reference * bar.volume
        vwap = weighted_pv / total_volume
    else:
        vwap = chunk[-1].vwap if chunk[-1].vwap is not None else chunk[-1].close

    session = next((bar.session for bar in reversed(chunk) if bar.session), None)
    return OhlcvBar(
        timestamp=bucket_ts,
        open=chunk[0].open,
        high=max(bar.high for bar in chunk),
        low=min(bar.low for bar in chunk),
        close=chunk[-1].close,
        volume=total_volume,
        session=session,
        vwap=vwap,
    )


def aggregate_ohlcv_bars(
    bars: list[OhlcvBar],
    interval_minutes: int,
    *,
    align_to_clock: bool = True,
) -> list[OhlcvBar]:
    if interval_minutes <= 1:
        return sorted(bars, key=lambda bar: bar.timestamp)
    if not bars:
        return []

    ordered = sorted(bars, key=lambda bar: bar.timestamp)
    out: list[OhlcvBar] = []

    if not align_to_clock:
        chunk: list[OhlcvBar] = []
        for bar in ordered:
            chunk.append(bar)
            if len(chunk) < interval_minutes:
                continue
            out.append(_aggregate_chunk(chunk, chunk[-1].timestamp))
            chunk = []
        if chunk:
            out.append(_aggregate_chunk(chunk, chunk[-1].timestamp))
        return out

    current_bucket = _bucket_start(ordered[0].timestamp, interval_minutes)
    chunk = [ordered[0]]
    for bar in ordered[1:]:
        bucket = _bucket_start(bar.timestamp, interval_minutes)
        if bucket != current_bucket:
            out.append(_aggregate_chunk(chunk, current_bucket))
            current_bucket = bucket
            chunk = [bar]
            continue
        chunk.append(bar)

    out.append(_aggregate_chunk(chunk, current_bucket))
    return out
