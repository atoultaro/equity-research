from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from .bars import OhlcvBar, aggregate_ohlcv_bars
from .indicators import ema_series


def _ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    if period <= 1:
        return values[:]
    try:
        return ema_series(values, period)
    except (TypeError, ValueError, OverflowError):
        # Preserve legacy permissive/nonfinite behavior outside the shared domain.
        pass
    alpha = 2.0 / (period + 1.0)
    out: list[float] = [values[0]]
    for value in values[1:]:
        out.append((alpha * value) + ((1.0 - alpha) * out[-1]))
    return out


def write_candlestick_plot(
    *,
    bars: list[OhlcvBar],
    output_path: Path | str,
    title: str,
    hlines: list[tuple[float, str, str]] | None = None,
    show_vwap_series: bool = False,
    xlim: tuple[datetime, datetime] | None = None,
    candle_minutes: int = 5,
    ema_periods: list[tuple[int, str, str]] | None = None,
    x_axis_label: str = "Time",
    dpi: int = 140,
) -> None:
    if not bars:
        raise ValueError(f"No bars available for plot: {title}")

    # Keep matplotlib cache/write paths safe for CLI runtime environments.
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")
    os.environ.setdefault("XDG_CACHE_HOME", "/tmp")

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.dates as mdates
    import matplotlib.patches as mpatches
    import matplotlib.pyplot as plt

    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    bars_candle = aggregate_ohlcv_bars(bars, interval_minutes=max(1, candle_minutes))
    if not bars_candle:
        raise ValueError(f"No bars available for plot after aggregation: {title}")

    opens = [bar.open for bar in bars_candle]
    highs = [bar.high for bar in bars_candle]
    lows = [bar.low for bar in bars_candle]
    closes = [bar.close for bar in bars_candle]
    volumes = [bar.volume for bar in bars_candle]
    xnums = mdates.date2num([bar.timestamp for bar in bars_candle])
    candle_width = (max(1, candle_minutes) / (24 * 60)) * 0.8
    vwap_vals = [bar.vwap if bar.vwap is not None else bar.close for bar in bars_candle]
    closes = [bar.close for bar in bars_candle]

    fig, (ax_price, ax_vol) = plt.subplots(
        2,
        1,
        figsize=(12, 6),
        sharex=True,
        gridspec_kw={"height_ratios": [3, 1]},
    )

    price_span = max(highs) - min(lows)
    min_body = max(price_span * 0.001, 0.01)
    for xnum, o, h, l, c in zip(xnums, opens, highs, lows, closes):
        up = c >= o
        fill_color = "#ffffff" if up else "#111111"
        ax_price.vlines(xnum, l, h, color="#000000", linewidth=0.9, alpha=0.95)

        body_height = abs(c - o)
        if body_height < min_body:
            body_bottom = ((o + c) / 2) - (min_body / 2)
            body_height = min_body
        else:
            body_bottom = min(o, c)

        rect = mpatches.Rectangle(
            (xnum - candle_width / 2, body_bottom),
            candle_width,
            body_height,
            facecolor=fill_color,
            edgecolor="#000000",
            linewidth=0.8,
            alpha=1.0,
        )
        ax_price.add_patch(rect)

    if show_vwap_series:
        ax_price.plot(xnums, vwap_vals, color="#ff7f0e", linewidth=1.0, alpha=0.9, label="VWAP")
    if ema_periods:
        for period, label, color in ema_periods:
            ax_price.plot(xnums, _ema(closes, period), color=color, linewidth=1.0, alpha=0.95, label=label)

    if hlines:
        for level, label, color in hlines:
            ax_price.axhline(level, color=color, linestyle="--", linewidth=0.9, alpha=0.85, label=label)

    ax_price.set_title(title)
    ax_price.set_ylabel("Price")
    ax_price.grid(True, alpha=0.2)
    handles, _labels = ax_price.get_legend_handles_labels()
    if handles:
        ax_price.legend(loc="best", fontsize=8)

    if xlim is not None:
        xlim_num = (mdates.date2num(xlim[0]), mdates.date2num(xlim[1]))
        ax_price.set_xlim(xlim_num)
        ax_vol.set_xlim(xlim_num)

    volume_colors = ["#ffffff" if c >= o else "#111111" for o, c in zip(opens, closes)]
    ax_vol.bar(
        xnums,
        volumes,
        width=candle_width,
        color=volume_colors,
        edgecolor="#000000",
        linewidth=0.6,
        alpha=1.0,
    )
    ax_vol.set_ylabel("Volume")
    ax_vol.set_xlabel(x_axis_label)
    ax_vol.grid(True, axis="y", alpha=0.2)

    tz = bars_candle[0].timestamp.tzinfo
    major_locator = mdates.AutoDateLocator(minticks=6, maxticks=10, interval_multiples=True, tz=tz)
    ax_price.xaxis.set_major_locator(major_locator)
    ax_vol.xaxis.set_major_locator(major_locator)
    ax_vol.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M", tz=tz))
    ax_price.margins(x=0)
    ax_vol.margins(x=0)

    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi)
    plt.close(fig)
